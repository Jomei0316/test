package Image;

import MyFile.ImageFileChooser;
import MyFile.MyImageFile;
import SimpleFactoryPattern.AbstractTool;
import StatePattern.EndState;
import StatePattern.MiddleState;
import StatePattern.StartState;

import java.awt.Toolkit;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Image;
import java.awt.Point;
import java.awt.image.BufferedImage;
import javax.swing.JColorChooser;
import javax.swing.JViewport;

import MementoPattern.CareTaker;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JOptionPane;
import java.io.File;
import javax.imageio.ImageIO;

/*
	这个类负责处理图像操作相关的业务逻辑，例如初始化绘图区域，重绘、处理撤销等。
	使用的设计模式：
		1.状态模式：用于管理撤销和重做操作的状态。
		2.备忘录模式：用于存储和恢复图像的状态。
		3.单例模式：确保ImageFrame类的唯一实例
		4.工厂模式：用于创建工具实例
	这个类是核心类
 */
public class ImageService {
	public BufferedImage myImage;
	private ImageFileChooser fileChooser = new ImageFileChooser();


	public void initDrawSpace(ImageFrame frame) {

		Graphics g = frame.getBufferedImage().getGraphics();

		Dimension d = frame.getDrawSpace().getPreferredSize();

		int drawWidth = (int) d.getWidth();

		int drawHeight = (int) d.getHeight();

		g.setColor(Color.WHITE);
		g.fillRect(0, 0, drawWidth, drawHeight);
	}

	//repaint
	public void repaint(Graphics g, BufferedImage bufferedImage) {
		int drawWidth = bufferedImage.getWidth();
		int drawHeight = bufferedImage.getHeight();
		Dimension screenSize = MyImageFile.getScreenSize();

		g.setColor(Color.GRAY);
		g.fillRect(0, 0, (int) screenSize.getWidth() * 10, (int) screenSize
				.getHeight() * 10);

		g.setColor(Color.BLUE);
		g.fillRect(drawWidth, drawHeight, 4, 4);
		g.fillRect(drawWidth, (int) drawHeight / 2 - 2, 4, 4);
		g.fillRect((int) drawWidth / 2 - 2, drawHeight, 4, 4);

		g.drawImage(bufferedImage, 0, 0, drawWidth, drawHeight, null);
	}


	public static Cursor createCursor(String path) {
		Image cursorImage = Toolkit.getDefaultToolkit().createImage(path);
		return Toolkit.getDefaultToolkit().createCustomCursor(cursorImage,
				new Point(10, 10), "mycursor");
	}


	public static void setViewport(JScrollPane scroll, JPanel panel, int width,
			int height) {

		JViewport viewport = new JViewport();

		panel.setPreferredSize(new Dimension(width + 50, height + 50));

		viewport.setView(panel);
		scroll.setViewport(viewport);
	}

	public void editColor(ImageFrame frame) {

		Color color = JColorChooser.showDialog(frame.getColorChooser(), "编辑颜色",
				Color.BLACK);
		color = color == null ? AbstractTool.color : color;

		AbstractTool.color = color;

		frame.getCurrentColorPanel().setBackground(color);
	}


	public void exit(ImageFrame frame) {
		MyImageFile myImageFile = new MyImageFile();
		myImageFile.save(false, frame);
		System.exit(0);
	}


	public void setVisible(JPanel panel) {
		boolean b = panel.isVisible() ? false : true;
		panel.setVisible(b);
	}



	public void Undo(ImageFrame frame){
        frame.originator.getStateFromMemento(frame.careTaker.Undo());
        myImage = frame.originator.getState();
		if(CareTaker.getInstance().index != 0){
			MiddleState middleState = new MiddleState();
			middleState.doAction(ImageFrame.getInstance().context);
		}else {
			StartState startState = new StartState();
			startState.doAction(ImageFrame.getInstance().context);
		}
	}

	public void Redo(ImageFrame frame){
        frame.originator.getStateFromMemento(frame.careTaker.Redo());
        myImage = frame.originator.getState();
		if(CareTaker.getInstance().index != CareTaker.getInstance().size() - 1){
			MiddleState middleState = new MiddleState();
			middleState.doAction(ImageFrame.getInstance().context);
		}
		else {
			EndState endState = new EndState();
			endState.doAction(ImageFrame.getInstance().context);
		}
	}


	public void menuDo(ImageFrame frame, String cmd) {
		if(cmd.equals("撤销(Ctrl+Z)")){
			Undo(frame);
		}

		if(cmd.equals("重做(Ctrl+Y)")){
			Redo(frame);
		}

		if (cmd.equals("编辑颜色")) {
			editColor(frame);
		}

		if (cmd.equals("工具箱(T)")) {
			setVisible(frame.getToolPanel());
		}

		if (cmd.equals("颜料盒(C)")) {
			setVisible(frame.getColorPanel());
		}

		if (cmd.equals("新建(N)")) {
			MyImageFile myImageFile = new MyImageFile();
			myImageFile.createGraphics(frame);
		}

		if (cmd.equals("打开(O)")) {
			MyImageFile myImageFile = new MyImageFile();
			myImageFile.open(frame);
		}

		if (cmd.equals("保存(Ctrl+S)")) {
			MyImageFile myImageFile = new MyImageFile();
			myImageFile.save(true, frame);
		}

		if (cmd.equals("退出(X)")) {
			exit(frame);
		}
	}

}