package StatePattern;

import Image.ImageFrame;

public class MiddleState implements State {
    public void doAction(Context context) {
        ImageFrame.getInstance().getJMenuBar().
                getMenu(1).getItem(0).setEnabled(true);
        ImageFrame.getInstance().getJMenuBar().
                getMenu(1).getItem(1).setEnabled(true);
        context.setState(this);
    }
}
