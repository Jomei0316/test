package StatePattern;

import Image.ImageFrame;

public class EndState implements State {
    public void doAction(Context context) {
        ImageFrame.getInstance().getJMenuBar().
                getMenu(1).getItem(0).setEnabled(true);
        ImageFrame.getInstance().getJMenuBar().
                getMenu(1).getItem(1).setEnabled(false);
        context.setState(this);
    }
}
