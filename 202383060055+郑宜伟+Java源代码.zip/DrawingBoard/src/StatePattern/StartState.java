package StatePattern;

import Image.ImageFrame;
import MementoPattern.CareTaker;

public class StartState implements State {
    public void doAction(Context context) {
        ImageFrame.getInstance().getJMenuBar().
                getMenu(1).getItem(0).setEnabled(false);
        ImageFrame.getInstance().getJMenuBar().
                getMenu(1).getItem(1).setEnabled(true);
        context.setState(this);
    }
}
