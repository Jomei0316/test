package Action;

import javax.swing.AbstractAction;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

import Image.ImageFrame;
import SimpleFactoryPattern.*;

import java.awt.Color;
import java.awt.event.ActionEvent;

/*
 * 这个类使用工厂模式来获取工具实例，并且在动作时间发生时，根据条件设置工具和颜色。
 * 构造函数提供了两种不同的初始化方式，以适应不同的使用场景。
 * 工厂模式通过ToolFactory类创建工具实例。
 */

public class ImageAction extends AbstractAction {
//	定义类和成员变量
	private String name = "";		//	存储工具名字
	private ImageFrame frame = null;	//	指向 ImageFrame 对象的引用，用于在执行操作时进行工具设置。
	private Color color = null;		//	存储颜色值
	private Tool tool = null;	//	工具对象，可能是由工厂模式生成的具体工具类
	private JPanel colorPanel = null;	//	一个JPanel对象，表示颜色面板


	public ImageAction(Color color, JPanel colorPanel) {
//	接受color对象和一个JPanel对象
		super();
		this.color = color;
		this.colorPanel = colorPanel;
	}


	public ImageAction(ImageIcon icon, String name, ImageFrame frame) {

		super("", icon);
		this.name = name;
		this.frame = frame;
	}

	public void actionPerformed(ActionEvent e) {

		tool = name != "" ? ToolFactory.getToolInstance(frame, name) : tool;
		if (tool != null) {

			frame.setTool(tool);
		}
		if (color != null) {
			AbstractTool.color = color;
			colorPanel.setBackground(color);
		}
	}
}