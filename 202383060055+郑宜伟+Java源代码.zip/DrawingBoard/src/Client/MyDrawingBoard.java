package Client;

import javax.swing.JFrame;

import Image.ImageFrame;


public class MyDrawingBoard {
	public static void main(String[] args) {
		ImageFrame f = ImageFrame.getInstance();
		f.pack();
		f.setVisible(true);
		f.setExtendedState(JFrame.MAXIMIZED_BOTH); 
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}