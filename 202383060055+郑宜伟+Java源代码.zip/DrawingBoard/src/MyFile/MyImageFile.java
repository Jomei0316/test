package MyFile;

import javax.imageio.ImageIO;
import javax.swing.*;

import Image.ImageFrame;
import Image.ImageService;
import Image.MyImage;
import SimpleFactoryPattern.AbstractTool;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;

public class MyImageFile {
    private ImageFileChooser fileChooser = new ImageFileChooser();
    
    //????????????b????????????
    public void save(boolean b, ImageFrame frame) {
        if (b) {
            // ???????
            if (fileChooser.showSaveDialog(frame) == ImageFileChooser.APPROVE_OPTION) {
                // ??????·??
                File currentDirectory = fileChooser.getCurrentDirectory();
                // ????????
                String fileName = fileChooser.getSelectedFile().getName();
                // ????????
                String suf = fileChooser.getSuf();
                // ??????·??
                String savePath = currentDirectory + "\\" + fileName + "."
                        + suf;
                try {
                    // ????д??????·??
                    ImageIO.write(frame.getBufferedImage(), suf, new File(
                            savePath));
                } catch (java.io.IOException ie) {
                    ie.printStackTrace();
                }
                // ???????????????
                frame.setTitle(fileName + "." + suf + " -画图");
                // ?????
                frame.getBufferedImage().setIsSaved(true);
            }
        } else if (!frame.getBufferedImage().isSaved()) {
            // ???????????
            JOptionPane option = new JOptionPane();
            // ?????????????YES_NO_OPTION
            int checked = option.showConfirmDialog(frame, "保存改动?", "画图",
                    option.YES_NO_OPTION, option.WARNING_MESSAGE);
            // ????????
            if (checked == option.YES_OPTION) {
                // ??????
                save(true, frame);
            }
        }
    }

    //????
    public void open(ImageFrame frame) {
        save(false, frame);
        // ???????????
        if (fileChooser.showOpenDialog(frame) == ImageFileChooser.APPROVE_OPTION) {
            // ??????????
            File file = fileChooser.getSelectedFile();
            // ???????????
            fileChooser.setCurrentDirectory(file);
            BufferedImage image = null;
            try {
                // ??????????
                image = ImageIO.read(file);
            } catch (java.io.IOException e) {
                e.printStackTrace();
                return;
            }
            // ????
            int width = image.getWidth();
            int height = image.getHeight();
            AbstractTool.drawWidth = width;
            AbstractTool.drawHeight = height;
            // ???????MyImage
            MyImage myImage = new MyImage(width, height,
                    BufferedImage.TYPE_INT_RGB);
            // ??????????????myImage????
            myImage.getGraphics().drawImage(image, 0, 0, width, height, null);
            frame.setBufferedImage(myImage);
            // repaint
            frame.getDrawSpace().repaint();
            // ????????viewport
            ImageService.setViewport(frame.getScroll(), frame.getDrawSpace(),
                    width, height);
            // ???????????????
            frame.setTitle(fileChooser.getSelectedFile().getName() + " -画图");
        }
    }

    //????
    public void createGraphics(ImageFrame frame) {
        save(false, frame);
        // ????
        int width = (int) getScreenSize().getWidth() / 2;
        int height = (int) getScreenSize().getHeight() / 2;
        AbstractTool.drawWidth = width;
        AbstractTool.drawHeight = height;
        // ???????MyImage
        MyImage myImage = new MyImage(width, height, BufferedImage.TYPE_INT_RGB);
        Graphics g = myImage.getGraphics();
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, width, height);
        frame.setBufferedImage(myImage);
        // repaint
        frame.getDrawSpace().repaint();
        // ????????viewport
        ImageService.setViewport(frame.getScroll(), frame.getDrawSpace(),
                width, height);
        // ???????????????
        frame.setTitle("新建-画图");
    }

    //???????????
    public static Dimension getScreenSize() {
        Toolkit dt = Toolkit.getDefaultToolkit();
        return dt.getScreenSize();
    }
}
