package SimpleFactoryPattern;

import javax.swing.*;

import Image.ImageFrame;

import java.awt.*;
import java.awt.event.MouseEvent;

public class NewTool  extends AbstractTool {
    private static Tool tool = null;

    private NewTool(ImageFrame frame) {
        super(frame, "img/textcursor.gif");
    }

    public static Tool getInstance(ImageFrame frame) {
        if (tool == null) {
            tool = new NewTool(frame);
        }
        return tool;
    }


   //���
    public void mouseClicked(MouseEvent e){
        super.mouseClicked(e);
        // ��ȡͼƬ��Graphics����
        Graphics g = getFrame().getBufferedImage().getGraphics();
        g.setColor(AbstractTool.color);
        getFrame().getDrawSpace().repaint();
        String string = JOptionPane.showInputDialog("������:");
        if(string == null) return;
        g.drawString(string, e.getX(), e.getY());
        getFrame().getDrawSpace().repaint();
    }
}
