package SimpleFactoryPattern;

import javax.swing.*;

import Image.ImageFrame;
import Image.ImageService;
import Image.MyImage;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;

//���ֹ���
public class TextTool extends AbstractTool {
    private static Tool tool = null;

    private TextTool(ImageFrame frame) {
        super(frame, "img/textcursor.gif");
    }

    public static Tool getInstance(ImageFrame frame) {
        if (tool == null) {
            tool = new TextTool(frame);
        }
        return tool;
    }


   // ���
    public void mouseClicked(MouseEvent e){
        super.mouseClicked(e);
        // ��ȡͼƬ��Graphics����
        Graphics g = getFrame().getBufferedImage().getGraphics();
        g.setColor(AbstractTool.color);
        getFrame().getDrawSpace().repaint();
        String string = JOptionPane.showInputDialog("������:");
        if(string == null) return;
        g.drawString(string, e.getX(), e.getY());
        getFrame().getDrawSpace().repaint();
    }
}
